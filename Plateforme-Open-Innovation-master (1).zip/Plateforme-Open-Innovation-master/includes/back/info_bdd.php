<?php
    // =========Information de Connexion=========
    // --------------Nom de L'hôte---------------
            $host = 'localhost';

    // ----------Nom de la Base de Donnée--------
            $dbname = 'Openinnov';
    
    // -----Identifiant de la Base de Donnée-----
            $dbuser = 'root';

    // -----Mot de Passe de la Base de Donnée----
            $dbpw = '';

    // ==========================================
?>
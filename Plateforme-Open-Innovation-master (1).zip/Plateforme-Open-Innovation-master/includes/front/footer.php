 
    <?php if($_SESSION['type'] == "etudiant"){ ?>
    <footer>
        <span> Copyright &copy; FOUVRY</span>
    </footer>
    <?php } ?>

    <div class="loader-wrapper" id="loader-wrapper">
        <div class="wrapper-img">
            <img src="../assets/img/loader.gif" alt="">
        </div>
    </div>

<?php include_once('fin.php'); ?>
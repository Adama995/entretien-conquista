
	
	<script src="../../assets/js/all.js"></script>
	<script type="module" src="../../assets/js/drop-file.js"></script>
	<script src="../../assets/js/script.js"></script>
	<script type="text/javascript" src="../../assets/js/skrollr.js"></script>
	<script type="text/javascript">
		var s = skrollr.init();
	</script>
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
</body>
</html>